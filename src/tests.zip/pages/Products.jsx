import { useState, useEffect } from "react";
import ProductCard from "../components/ProductCard";
import { fetchProducts } from "../services/api";

function Products({ addToCart, wishlist, toggleWishlist }) {

  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [currentPage, setCurrentPage] = useState(1);

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const itemsPerPage = 4;

  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(search);
    }, 500);

    return () => clearTimeout(timer);
  }, [search]);

  // Load products from API
  useEffect(() => {

    async function loadProducts() {

      try {

        const data = await fetchProducts();
        setProducts(data);

      } catch (err) {

        setError("Failed to load products");

      } finally {

        setLoading(false);

      }

    }

    loadProducts();

  }, []);

  // Filter products
  const filteredProducts = products.filter((product) =>
    product.title.toLowerCase().includes(debouncedSearch.toLowerCase())
  );

  // Pagination
  const totalPages = Math.ceil(filteredProducts.length / itemsPerPage);

  const paginatedProducts = filteredProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Loading state
  if (loading) {
    return <h2 style={{ textAlign: "center" }}>Loading products...</h2>;
  }

  // Error state
  if (error) {
    return <h2 style={{ textAlign: "center" }}>{error}</h2>;
  }

  return (
    <div style={{ padding: "40px" }}>

      <h2 style={{ textAlign: "center" }}>Our Products</h2>

      {/* Search */}
      <div style={{ textAlign: "center", margin: "20px 0" }}>
        <input
          aria-label="Search products"
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={(e) => {
            setSearch(e.target.value);
            setCurrentPage(1);
          }}
          style={{ padding: "10px", width: "300px" }}
        />
      </div>

      {/* No Results */}
      {filteredProducts.length === 0 && (
        <h3 style={{ textAlign: "center" }}>No products found</h3>
      )}

      {/* Product Grid */}
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          gap: "30px",
          justifyContent: "center"
        }}
      >

        {paginatedProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            addToCart={addToCart}
            wishlist={wishlist}
            toggleWishlist={toggleWishlist}
          />
        ))}

      </div>

      {/* Pagination */}
      <div style={{ textAlign: "center", marginTop: "30px" }}>

        {[...Array(totalPages)].map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentPage(index + 1)}
            style={{
              margin: "5px",
              padding: "8px 12px",
              backgroundColor:
                currentPage === index + 1 ? "black" : "#ddd",
              color: currentPage === index + 1 ? "white" : "black",
              border: "none",
              cursor: "pointer"
            }}
          >
            {index + 1}
          </button>
        ))}

      </div>

    </div>
  );
}

export default Products;