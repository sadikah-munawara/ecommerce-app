import { useEffect, useState } from "react";

function AdminDashboard() {

  const [orders, setOrders] = useState([]);
  const [revenue, setRevenue] = useState(0);

  useEffect(() => {

    const savedOrders =
      JSON.parse(localStorage.getItem("orders")) || [];

    setOrders(savedOrders);

    const totalRevenue = savedOrders.reduce(
      (sum, order) => sum + order.total,
      0
    );

    setRevenue(totalRevenue);

  }, []);

  return (

    <div style={{ display: "flex", minHeight: "80vh" }}>

      {/* SIDEBAR */}

      <div
        style={{
          width: "220px",
          background: "#f4f4f4",
          padding: "20px"
        }}
      >
        <h3>Admin</h3>

        <p>Dashboard</p>
        <p>Orders</p>
        <p>Users</p>
        <p>Products</p>

      </div>

      {/* DASHBOARD */}

      <div style={{ flex: 1, padding: "40px" }}>

        <h1>Admin Dashboard</h1>

        {/* KPI TILES */}

        <div
          style={{
            display: "flex",
            gap: "20px",
            marginTop: "30px"
          }}
        >

          <div
            style={{
              padding: "20px",
              border: "1px solid #ddd",
              borderRadius: "10px",
              width: "200px"
            }}
          >
            <h3>Total Orders</h3>
            <h2>{orders.length}</h2>
          </div>

          <div
            style={{
              padding: "20px",
              border: "1px solid #ddd",
              borderRadius: "10px",
              width: "200px"
            }}
          >
            <h3>Total Revenue</h3>
            <h2>₹ {revenue}</h2>
          </div>

        </div>

        {/* TREND CARDS */}

        <div style={{ marginTop: "40px" }}>

          <h3>Recent Orders</h3>

          {orders.slice(0,3).map((order) => (

            <div
              key={order.id}
              style={{
                borderBottom: "1px solid #ddd",
                padding: "10px 0"
              }}
            >
              {order.id} — ₹{order.total}
            </div>

          ))}

        </div>

      </div>

    </div>

  );

}

export default AdminDashboard;