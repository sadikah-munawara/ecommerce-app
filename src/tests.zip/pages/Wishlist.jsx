import products from "../data/products";

function Wishlist({ wishlist }) {

  const wishlistProducts = products.filter((p) =>
    wishlist.includes(p.id)
  );

  return (
    <div style={{ padding: "40px" }}>

      <h2>My Wishlist</h2>

      {wishlistProducts.length === 0 ? (
        <p>No items in wishlist</p>
      ) : (
        wishlistProducts.map((product) => (
          <div key={product.id} style={{ marginBottom: "20px" }}>
  <img src={product.image} width="100" />
  <h4>{product.title}</h4>
  <p>₹ {product.price}</p>
</div>
        ))
      )}

    </div>
  );
}

export default Wishlist;