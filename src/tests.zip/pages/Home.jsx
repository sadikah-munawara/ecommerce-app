function Home() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",   // vertical center
        alignItems: "center",       // horizontal center
        height: "80vh",
        textAlign: "center"
      }}
    >
      <h1>Welcome to MyStore 🛍️</h1>
      <p>Your one-stop shop for amazing products.</p>
      <h3>🔥 Explore our latest collections!</h3>
    </div>
  );
}

export default Home;