export async function fetchProducts() {

  const cached = localStorage.getItem("products");

  if (cached) {
    return JSON.parse(cached);
  }

  const response = await fetch(
    "https://fakestoreapi.com/products"
  );

  if (!response.ok) {
    throw new Error("Failed to fetch products");
  }

  const data = await response.json();

  localStorage.setItem(
    "products",
    JSON.stringify(data)
  );

  return data;
}