import { Navigate } from "react-router-dom";

function ProtectedRoute({ children }) {

  const savedProfile = localStorage.getItem("profile");

  if (!savedProfile) {
    return <Navigate to="/" />;
  }

  return children;
}

export default ProtectedRoute;