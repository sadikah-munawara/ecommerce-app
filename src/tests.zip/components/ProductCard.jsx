import { Link } from "react-router-dom";
import React from "react";

function ProductCard({ product, addToCart, wishlist, toggleWishlist }) {

  const isWishlisted = wishlist.includes(product.id);

  return (
    <div
      style={{
        border: "1px solid #ddd",
        padding: "15px",
        width: "240px",
        position: "relative"
      }}
    >

      <button
        aria-label="Add product to wishlist"
        onClick={() => toggleWishlist(product.id)}
        style={{
          position: "absolute",
          top: "10px",
          right: "10px",
          background: "none",
          border: "none",
          fontSize: "22px",
          cursor: "pointer"
        }}
      >
        {isWishlisted ? "❤️" : "🤍"}
      </button>

      <img
        src={product.image}
        alt={product.title}
        style={{
          width: "100%",
          height: "200px",
          objectFit: "cover"
        }}
      />

      <Link
        to={`/product/${product.id}`}
        style={{ textDecoration: "none", color: "black" }}
      >
        <h3>{product.title}</h3>
      </Link>

      <p>₹ {product.price}</p>

      <button
        aria-label="Add product to cart"
        onClick={() => addToCart({ ...product, quantity: 1 })}
      >
        Add to Cart
      </button>

    </div>
  );
}

export default React.memo(ProductCard);